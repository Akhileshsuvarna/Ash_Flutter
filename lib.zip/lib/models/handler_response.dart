class HandlerResponse {
  // HandlerResponse(this.message, this.success, this.statusCode, this.dataObject);
  late String message;
  late bool success;
  late int statusCode;
  late HandlerModel dataObject;
}

class HandlerModel {}
