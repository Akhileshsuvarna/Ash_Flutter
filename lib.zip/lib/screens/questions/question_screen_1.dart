import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:health_connector/util/device_utils.dart';

import '../../constants.dart';

class QuestionScreen extends StatefulWidget {
  const QuestionScreen({Key? key}) : super(key: key);

  @override
  _QuestionScreenState createState() => _QuestionScreenState();
}

class _QuestionScreenState extends State<QuestionScreen> {
  int _questionIndex = 0;
  int _answerIndex = 0;

  bool answerWasSelected = false;
  bool endOfQuiz = false;

  final _formKey = GlobalKey<FormState>();
  bool _autovalidate = false;

  String? _selectedColor;

  void _nextQuestion() async {
    setState(() {


      if (_questionIndex == 4 && _answerIndex ==4){
        print("answewr index one ::::::::::::::::" +
            _answer[_answerIndex]['answers']![1].toString());
        print ("selected colour:::::::::::::::::"+_selectedColor!);
        if( _selectedColor?.toLowerCase() == _answer[_answerIndex]['answers']![1].toLowerCase() || _selectedColor == _answer[_answerIndex]['answers']![2]){
          _questionIndex=6;
          _answerIndex = 6;
          _selectedColor = null;
          return;
        }
        else if (_selectedColor == _answer[_answerIndex]['answers']![0]) {
          _questionIndex=5;
          _answerIndex = 5;
          _selectedColor = null;
          return;
        }
      }
      if (_questionIndex == 5 && _answerIndex == 5 && _selectedColor != null ) {
        Navigator.of(context).pushReplacementNamed(Constants.exerciseScreen);
      }
      else  if (_questionIndex == 6 && _answerIndex == 6 && _selectedColor != null) {
        Navigator.of(context).pushReplacementNamed(Constants.exerciseScreen);
      }

      else{
        if(_questionIndex < 5 && _answerIndex <5){
          _questionIndex++;
          _answerIndex++;
        }

      _selectedColor = null;
      }
      // correctAnswerSelected = false;
    });

  }

  void _previousQuestion() async {
    setState(() {
      _questionIndex--;
      _answerIndex--;
      _selectedColor = null;
    });

    if (_questionIndex == 0 && _answerIndex == 0  ) {
      Navigator.of(context).pushReplacementNamed(Constants.questionScreen);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Constants.profileBackground,
        body: SingleChildScrollView(
          child: Form(
            key: _formKey,
            autovalidate: _autovalidate,
            child: Stack(
              children: <Widget>[
                Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Padding(
                      padding: EdgeInsets.only(
                          left: DeviceUtils.width(context) / 150,
                          top: DeviceUtils.height(context) / 60),
                      child: Stack(children: [
                        Padding(
                          padding: EdgeInsets.only(
                              left: DeviceUtils.width(context) / 150,
                              top: DeviceUtils.height(context) / 60),
                          child: Align(
                            alignment: Alignment.topLeft,
                            child: IconButton(
                              icon: const Icon(
                                Icons.arrow_back_ios_new_sharp,
                                color: Color(0xFF7E57C2),
                                size: 25,
                              ),
                              onPressed: () {
                                _previousQuestion();
                                // if(_questionIndex ==0 ){}
                                // Navigator.of(context).pushReplacementNamed(
                                //     Constants.questionScreen);
                              },
                            ),
                          ),
                        ),
                        logoDetails(),
                      ]),
                    ),
                    questionCard(),
                    _questionIndex != 1 ? dropDown() : textField(),
                  ],
                ),
                continewButton(),
              ],
            ),
          ),
        ));
  }

  Widget logoDetails() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      // crossAxisAlignment: CrossAxisAlignment.stretch,
      //mainAxisSize: MainAxisSize.max,
      children: <Widget>[
        Padding(
          padding: EdgeInsets.only(top: DeviceUtils.height(context) / 30),
          child: ClipRect(
              child: Align(
            alignment: Alignment.center,
            heightFactor: 1,
            child: Image.asset(
              'assets/images/prescription.gif',
              width: 300,
              height: 300,
              fit: BoxFit.fill,
              scale: 1.0,
            ),
          )),
        )
      ],
    );
  }

  Widget questionCard() {
    return Padding(
      padding: EdgeInsets.only(
          left: DeviceUtils.width(context) / 30,
          right: DeviceUtils.width(context) / 30,
          // top: DeviceUtils.height(context) / 20
      ),
      child: Card(
        elevation: 7.0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10), // if you need this
        ),
        color: Colors.grey[200],
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              //mainAxisSize: MainAxisSize.max,
              children: <Widget>[
                Padding(
                  padding: EdgeInsets.only(
                      left: DeviceUtils.width(context) / 30,
                      top: DeviceUtils.height(context) / 50),
                  child: const Text("Welcome,",
                      textAlign: TextAlign.left,
                      style: TextStyle(
                          color: Color(0xFF7E57C2),
                          fontSize: 20.0,
                          fontFamily: 'Lexend Deca',
                          fontWeight: FontWeight.bold)),
                ),
                Padding(
                  padding: EdgeInsets.only(
                      right: DeviceUtils.width(context) / 30,
                      top: DeviceUtils.height(context) / 50),
                  child: Text(_questions[_questionIndex]['count']!,
                      textDirection: TextDirection.ltr,
                      textAlign: TextAlign.left,
                      style: const TextStyle(
                          color: Color(0xFF7E57C2),
                          fontSize: 20.0,
                          fontFamily: 'Lexend Deca',
                          fontWeight: FontWeight.bold)),
                )
              ],
            ),
            Padding(
              padding: EdgeInsets.only(
                  left: DeviceUtils.width(context) / 30,
                  right: DeviceUtils.width(context) / 30,
                  top: DeviceUtils.height(context) / 50),
              child: Align(
                alignment: Alignment.center,
                child: Text(_questions[_questionIndex]['question']!,
                    // "How many areas of concern do you have?",
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      color: Color(0xFF313131),
                      fontSize: 20,
                      fontFamily: 'Lexend Deca',
                      fontWeight: FontWeight.w500,
                    )),
              ),
            ),
            Padding(
              padding: EdgeInsets.only(
                  left: DeviceUtils.width(context) / 30,
                  right: DeviceUtils.width(context) / 30,
                  top: DeviceUtils.height(context) / 25,
                  bottom: DeviceUtils.height(context) / 30),
              child: const Align(
                alignment: Alignment.center,
                child: Text("Choose from the following list below.",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        color: Color(0xFF313131),
                        fontSize: 20,
                        fontFamily: 'Lexend Deca',
                        fontWeight: FontWeight.w500)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget dropDown() {
    return Padding(
      padding: EdgeInsets.only(
          left: DeviceUtils.width(context) / 10,
          right: DeviceUtils.width(context) / 10,
          top: DeviceUtils.height(context) / 30),
      child: Container(
        // width: 100,
        // padding: EdgeInsets.symmetric(vertical: 5, horizontal: 15),
        decoration: BoxDecoration(
            color: Theme.of(context).primaryColor,
            borderRadius: BorderRadius.circular(10)),

        child: DropdownButtonFormField<String>(
          decoration: const InputDecoration(
              enabledBorder: UnderlineInputBorder(
                  borderSide: BorderSide(color: Colors.transparent))),
          onChanged: (value) {
            // if (_answerIndex == 4) {
            //   if(value == _answer[_answerIndex]['answers']![1] ||value == _answer[_answerIndex]['answers']![2]){
            //     _questionIndex==6;
            //     _answerIndex == 6;
            //   }
            //
            //   else if (value == _answer[_answerIndex]['answers']![0]) {
            //     _questionIndex==5;
            //     _answerIndex == 5;
            //   }
              //  else if(value == _answer[_answerIndex]['answers']![1] ||value == _answer[_answerIndex]['answers']![2]){
              //   _questionIndex==6;
              //   _answerIndex == 6;
              // }
            // }

            setState(() {
              print("answewrnumber::::::::::::::::" + _answerIndex.toString());
              print("answewr::::::::::::::::" + value.toString());
              print("answewr index ::::::::::::::::" +
                  _answer[_answerIndex]['answers']![0].toString());
              _selectedColor = value;
            });
          },
          value: _selectedColor,

          // Hide the default underline
          // underline: Container(),
          hint: Padding(
            padding: EdgeInsets.only(
                left: DeviceUtils.width(context) / 20,
                top: DeviceUtils.height(context) / 200),
            child: const Text(
              'Please select...',
              textAlign: TextAlign.start,
              style: TextStyle(
                  color: Colors.white,
                  fontSize: 14.0,
                  fontFamily: 'Lexend Deca',
                  fontWeight: FontWeight.bold),
            ),
          ),
          icon: Padding(
            padding: EdgeInsets.only(
                right: DeviceUtils.width(context) / 20,
                top: DeviceUtils.height(context) / 300),
            child: const Icon(
              Icons.arrow_drop_down,
              color: Colors.black38,
            ),
          ),
          isExpanded: true,
          validator: (value) => value == null ? 'field required' : null,
          // The list of options
          items: _answer[_answerIndex]['answers']!
              .map((e) => DropdownMenuItem(
                    child: Container(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        e,
                        style: const TextStyle(
                            color: Colors.black,
                            fontSize: 14.0,
                            fontFamily: 'Lexend Deca',
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                    value: e,
                  ))
              .toList(),

          // Customize the selected item

          selectedItemBuilder: (BuildContext context) =>
              _answer[_answerIndex]['answers']!
                  .map((e) => Center(
                        child: Text(
                          e,
                          style: const TextStyle(
                              color: Colors.white,
                              fontSize: 14.0,
                              fontFamily: 'Lexend Deca',
                              fontWeight: FontWeight.bold),
                        ),
                      ))
                  .toList(),
        ),
      ),
    );
  }

  Widget textField() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Padding(
          padding: EdgeInsets.only(
              left: DeviceUtils.width(context) / 35,
              right: DeviceUtils.width(context) / 35,
              top: DeviceUtils.height(context) / 30),
          child: const SizedBox(
            // height:DeviceUtils.width(context) / 5,
            child: TextField(
              style: TextStyle(
                  color: Colors.black,
                  fontSize: 14.0,
                  fontFamily: 'Lexend Deca',
                  fontWeight: FontWeight.bold),
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                border: OutlineInputBorder(),
                labelText: "Enter Your Age",
                labelStyle: TextStyle(
                    color: Colors.black,
                    fontSize: 14.0,
                    fontFamily: 'Lexend Deca',
                    fontWeight: FontWeight.bold),
                hintText: "Enter Your Age",
                hintStyle: TextStyle(
                    color: Colors.black,
                    fontSize: 14.0,
                    fontFamily: 'Lexend Deca',
                    fontWeight: FontWeight.bold),
              ),
              autofocus: false,
            ),
          ),
        ),
      ],
    );
  }

  Widget continewButton() {
    return Padding(
      padding: EdgeInsets.only(
        left: DeviceUtils.width(context) / 3.5,
        top: DeviceUtils.height(context) / 1.2,
      ),
      child: Row(
        children: [
          Align(
            alignment: Alignment.center,
            child: Container(
              width: DeviceUtils.width(context) / 2.5,
              child: ElevatedButton(
                  onPressed: () {
                    if (_formKey.currentState!.validate()) {
                      //form is valid, proceed further
                      _formKey.currentState!
                          .save(); //save once fields are valid, onSaved method invoked for every form fields

                    } else {
                      setState(() {
                        _autovalidate = true; //enable realtime validation
                      });
                    }
                    _nextQuestion();
                  },
                  style: ElevatedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(5.0),
                    ),
                    elevation: 10,
                    primary: Colors.white,
                  ),
                  child: const Text('Continue',
                      style: TextStyle(
                          color: Colors.lightBlueAccent,
                          fontSize: 20.0,
                          fontFamily: 'Lexend Deca',
                          fontWeight: FontWeight.bold))),
            ),
          ),
        ],
      ),
    );
  }
}

const _questions = [
  {
    'question': 'How many areas of concern do you have?',
    'count': '1/5',
  },
  {
    'question': 'What are your areas of concern?',
    'count': '2/5',
  },
  {
    'question': 'How long have you had this pain for?',
    'count': '3/5',
  },
  {
    'question': 'Is this the first time you’ve had this pain or is it ongoing?',
    'count': '4/5',
  },
  {
    'question': 'What is your current level of activity?',
    'count': '5/5',
  },
  {
    'question': 'Why are you not currently exercising?',
    'count': '5_a',
  },
  {
    'question': 'How many times per week do you exercise?',
    'count': '5(b)',
  },
];
const _answer = [
  {
    'answers': [" 0-1", "2-3", "  >3"],
  },
  {
    'answers': [" hello", "weeks", "gfccjgf"],
  },
  {
    'answers': [" 0-6 weeks", "7-12 weeks", ">12 weeks"],
  },
  {
    'answers': [" First time", "Ongoing "],
  },
  {
    'answers': [
      " No exercise",
      "Physiotherapy guided exercise",
      "Independent exercise"
    ],
  },
  {
    'answers': [
      " Due to pain",
      "Do not have the resources ",
    ],
  },
  {
    'answers': ["0-1", "2-4 ", ">4"],
  },
];
