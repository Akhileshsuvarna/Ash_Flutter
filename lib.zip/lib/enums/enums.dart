enum ExerciseType { catcow, sphinx, plank }

enum Operator { lessThan, greaterThan, equal }

enum Axis { X, Y }

enum GreaterNode { first, second }
